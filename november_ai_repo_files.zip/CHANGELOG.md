# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2025-07-19
### Added
- Initial project scaffolding
- User authentication
- November AI login screen UI

### Fixed
- Login redirect loop

## [0.9.0] - 2025-07-10
### Added
- Base project structure