# Code of Conduct

We are committed to a welcoming and inclusive environment.

## Our Standards
Examples of behavior that contributes:
- Respectful communication
- Constructive feedback
- Open collaboration

## Enforcement
Violations may be reported to the maintainers and will be addressed promptly.